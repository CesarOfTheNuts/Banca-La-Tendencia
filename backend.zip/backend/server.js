﻿require("dotenv").config()

const express = require("express")
const cors = require("cors")

const app = express()
app.use(cors())
app.use(express.json())

const usersDemo = [
  { id: 1, nombre: "Julio Martínez", nombre_usuario: "Julio", password: "123", rol: "Gerente", id_sucursal: "B001" },
  { id: 2, nombre: "Laura Pérez", nombre_usuario: "lperez", password: "123", rol: "Supervisor", id_sucursal: "B001" },
  { id: 3, nombre: "Carlos Núñez", nombre_usuario: "cnunez", password: "123", rol: "Cajero", id_sucursal: "B002" },
  { id: 4, nombre: "Andrea Santos", nombre_usuario: "asantos", password: "123", rol: "Admin", id_sucursal: "B001" },
  { id: 5, nombre: "María Gómez", nombre_usuario: "mgomez", password: "123", rol: "Auditor", id_sucursal: "B003" }
]

const sucursales = [
  { id: "B001", nombre: "Sucursal Central", zona: "Distrito Nacional", efectivo_actual: 4500000 },
  { id: "B002", nombre: "Sucursal Santiago", zona: "Norte", efectivo_actual: 2800000 },
  { id: "B003", nombre: "Sucursal Punta Cana", zona: "Este", efectivo_actual: 1950000 }
]

const cajas = [
  { id: "C001", sucursal: "B001", nombre: "Caja 01", responsable: "Laura Pérez", saldo: 650000, estado: "Abierta" },
  { id: "C002", sucursal: "B001", nombre: "Caja 02", responsable: "Ricardo Peña", saldo: 520000, estado: "Abierta" },
  { id: "C003", sucursal: "B002", nombre: "Caja 03", responsable: "Carlos Núñez", saldo: 380000, estado: "Abierta" },
  { id: "C004", sucursal: "B002", nombre: "Caja 04", responsable: "Diana Ruiz", saldo: 295000, estado: "Cerrada" },
  { id: "C005", sucursal: "B003", nombre: "Caja 05", responsable: "Esther Díaz", saldo: 410000, estado: "Abierta" }
]

app.get("/", (req, res) => {
  res.json({ system: "Banco La Tendencia", backend: "activo", status: "ok" })
})

app.post("/api/login", (req, res) => {
  const { username, password } = req.body || {}
  const user = usersDemo.find(u => u.nombre_usuario === username && u.password === password)

  if (!user) {
    return res.status(400).json({ ok: false, error: "Usuario o contraseña incorrectos" })
  }

  res.json({
    ok: true,
    user: {
      id: user.id,
      name: user.nombre,
      username: user.nombre_usuario,
      role: user.rol,
      branch: user.id_sucursal
    }
  })
})

app.get("/api/sucursales", (req, res) => {
  res.json({ ok: true, data: sucursales })
})

app.get("/api/cajas", (req, res) => {
  res.json({ ok: true, data: cajas })
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`)
})
