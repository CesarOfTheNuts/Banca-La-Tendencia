const $ = (id) => document.getElementById(id);

const LS = {
  state: "blt_cash_mgmt_state_v1",
  session: "blt_cash_mgmt_session_v1",
  remembered: "blt_cash_mgmt_remembered_v1"
};

let modalMode = null;

function formatMoney(value) {
  return new Intl.NumberFormat("es-DO", {
    style: "currency",
    currency: "DOP",
    maximumFractionDigits: 2
  }).format(value || 0);
}

function nowISO() {
  return new Date().toISOString();
}

function parseAmount(v) {
  const n = Number(String(v || "").replaceAll(",", "").trim());
  return Number.isFinite(n) ? n : NaN;
}

function uid() {
  return crypto.randomUUID?.() || ("id_" + Math.random().toString(16).slice(2));
}

function saveState(state) {
  localStorage.setItem(LS.state, JSON.stringify(state));
}

function loadState() {
  const raw = localStorage.getItem(LS.state);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}

function saveSession(session) {
  localStorage.setItem(LS.session, JSON.stringify(session));
}

function loadSession() {
  const raw = localStorage.getItem(LS.session);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}

function clearSession() {
  localStorage.removeItem(LS.session);
}

function setRememberedUser(value) {
  localStorage.setItem(LS.remembered, value);
}

function getRememberedUser() {
  return localStorage.getItem(LS.remembered) || "";
}

function clearRememberedUser() {
  localStorage.removeItem(LS.remembered);
}

function getInitialState() {
  return {
    users: [
      { id: uid(), name: "Julio Mart�nez", username: "Julio", password: "123", role: "Gerente", branchId: "b1", active: true },
      { id: uid(), name: "Laura P�rez", username: "lperez", password: "123", role: "Supervisor", branchId: "b1", active: true },
      { id: uid(), name: "Carlos N��ez", username: "cnunez", password: "123", role: "Cajero", branchId: "b2", active: true },
      { id: uid(), name: "Mar�a G�mez", username: "mgomez", password: "123", role: "Auditor", branchId: "b3", active: true }
    ],
    branches: [
      { id: "b1", name: "Sucursal Central", zone: "Distrito Nacional", cash: 450000 },
      { id: "b2", name: "Sucursal Santiago", zone: "Norte", cash: 320000 },
      { id: "b3", name: "Sucursal Punta Cana", zone: "Este", cash: 210000 }
    ],
    boxes: [
      { id: "x1", branchId: "b1", name: "Caja 01", responsible: "Laura P�rez", balance: 65000, status: "Abierta" },
      { id: "x2", branchId: "b1", name: "Caja 02", responsible: "Ricardo Pe�a", balance: 50000, status: "Cerrada" },
      { id: "x3", branchId: "b2", name: "Caja 03", responsible: "Carlos N��ez", balance: 42000, status: "Abierta" },
      { id: "x4", branchId: "b2", name: "Caja 04", responsible: "Diana Ruiz", balance: 36000, status: "Abierta" },
      { id: "x5", branchId: "b3", name: "Caja 05", responsible: "Esther D�az", balance: 28000, status: "Cerrada" },
      { id: "x6", branchId: "b3", name: "Caja 06", responsible: "Pedro Lara", balance: 31000, status: "Abierta" }
    ],
    movements: [],
    treasury: [],
    audit: [],
    settings: {
      currentTab: "dashboard"
    }
  };
}

function ensureState() {
  let state = loadState();
  if (!state) {
    state = getInitialState();
    addAudit(state, "Sistema inicializado", "Carga inicial del entorno demo");
    saveState(state);
  }
  return state;
}

function addAudit(state, action, detail) {
  const session = loadSession();
  const user = session?.username || "Sistema";
  const role = session?.role || "Sistema";

  state.audit.unshift({
    id: uid(),
    date: nowISO(),
    user,
    role,
    action,
    detail
  });
}

function showLoginMsg(text, type = "err") {
  const el = $("loginMsg");
  el.textContent = text;
  el.classList.remove("hidden", "ok", "err");
  el.classList.add(type === "ok" ? "ok" : "err");
}

function showMovementMsg(text, type = "ok") {
  const el = $("movementMsg");
  el.textContent = text;
  el.classList.remove("hidden", "ok", "err");
  el.classList.add(type === "ok" ? "ok" : "err");
}

function hideMessages() {
  ["loginMsg", "movementMsg"].forEach(id => {
    const el = $(id);
    if (el) {
      el.classList.add("hidden");
      el.textContent = "";
      el.classList.remove("ok", "err");
    }
  });
}

function getBranchName(state, branchId) {
  return state.branches.find(b => b.id === branchId)?.name || "�";
}

function getBoxName(state, boxId) {
  return state.boxes.find(b => b.id === boxId)?.name || "�";
}

function getCurrentUser(state) {
  const session = loadSession();
  if (!session) return null;
  return state.users.find(u => u.username === session.username) || null;
}

function updateBranchSelects(state) {
  const branchSelectIds = ["boxBranch", "mvBranch", "fundBranch", "remBranch", "newUserBranch", "modalBranch"];
  branchSelectIds.forEach(id => {
    const el = $(id);
    if (!el) return;
    const current = el.value;
    el.innerHTML = state.branches.map(b => `<option value="${b.id}">${b.name}</option>`).join("");
    if (state.branches.some(b => b.id === current)) el.value = current;
  });

  updateBoxSelects(state);
}

function updateBoxSelects(state) {
  const mvBranch = $("mvBranch")?.value || state.branches[0]?.id;
  const modalBranch = $("modalBranch")?.value || state.branches[0]?.id;

  const fillBoxes = (selectId, branchId) => {
    const el = $(selectId);
    if (!el) return;
    const filtered = state.boxes.filter(b => b.branchId === branchId);
    el.innerHTML = filtered.map(b => `<option value="${b.id}">${b.name}</option>`).join("");
  };

  fillBoxes("mvBox", mvBranch);
  fillBoxes("modalBox", modalBranch);
}

function setTab(tab) {
  const state = ensureState();
  state.settings.currentTab = tab;
  saveState(state);

  document.querySelectorAll(".nav-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.tab === tab);
  });

  document.querySelectorAll(".tab-panel").forEach(panel => {
    panel.classList.toggle("hidden", panel.dataset.panel !== tab);
  });

  render();
}

function renderBranchBars(state) {
  const wrap = $("branchBars");
  if (!wrap) return;
  wrap.innerHTML = "";

  const entries = state.branches.map(b => ({ name: b.name, value: b.cash }));
  const max = Math.max(...entries.map(e => e.value), 1);

  entries.forEach(entry => {
    const pct = Math.round((entry.value / max) * 100);
    wrap.insertAdjacentHTML("beforeend", `
      <div class="bar-row">
        <div class="bar-name">${entry.name}</div>
        <div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div>
        <div class="bar-value">${formatMoney(entry.value)}</div>
      </div>
    `);
  });
}

function computeAlerts(state) {
  const alerts = [];

  state.boxes.forEach(box => {
    if (box.balance > 70000) {
      alerts.push({ level: "rojo", text: `${box.name} excede el umbral de caja con ${formatMoney(box.balance)}.` });
    }
    if (box.status === "Abierta" && box.balance < 10000) {
      alerts.push({ level: "amarillo", text: `${box.name} tiene bajo efectivo disponible.` });
    }
  });

  state.movements.slice(0, 25).forEach(mv => {
    if (mv.alert) alerts.push({ level: "rojo", text: mv.alert });
  });

  return alerts.slice(0, 8);
}

function renderAlerts(state) {
  const list = $("alertsList");
  list.innerHTML = "";
  const alerts = computeAlerts(state);

  if (!alerts.length) {
    list.innerHTML = `<div class="list-item">Sin alertas activas.</div>`;
    return;
  }

  alerts.forEach(alert => {
    list.insertAdjacentHTML("beforeend", `<div class="list-item"><b>${alert.level.toUpperCase()}</b> � ${alert.text}</div>`);
  });
}

function renderRecentOps(state) {
  const list = $("recentOpsList");
  list.innerHTML = "";

  const recent = [
    ...state.movements.slice(0, 6).map(m => ({
      title: m.type,
      text: `${m.detail} � ${m.responsible} � ${new Date(m.date).toLocaleString("es-DO")}`
    })),
    ...state.treasury.slice(0, 3).map(t => ({
      title: t.kind,
      text: `${t.detail} � ${new Date(t.date).toLocaleString("es-DO")}`
    }))
  ].slice(0, 8);

  if (!recent.length) {
    list.innerHTML = `<div class="list-item">No hay operaciones registradas.</div>`;
    return;
  }

  recent.forEach(op => {
    list.insertAdjacentHTML("beforeend", `<div class="list-item"><b>${op.title}</b><br>${op.text}</div>`);
  });
}

function renderBranchesTable(state) {
  $("branchesTableWrap").innerHTML = `
    <table>
      <thead><tr><th>Sucursal</th><th>Zona</th><th class="right">Efectivo disponible</th></tr></thead>
      <tbody>
        ${state.branches.map(b => `<tr><td>${b.name}</td><td>${b.zone}</td><td class="right">${formatMoney(b.cash)}</td></tr>`).join("")}
      </tbody>
    </table>
  `;
}

function renderBoxesTable(state) {
  $("boxesTableWrap").innerHTML = `
    <table>
      <thead><tr><th>Caja</th><th>Sucursal</th><th>Responsable</th><th>Estado</th><th class="right">Saldo</th></tr></thead>
      <tbody>
        ${state.boxes.map(b => `<tr><td>${b.name}</td><td>${getBranchName(state, b.branchId)}</td><td>${b.responsible}</td><td>${b.status}</td><td class="right">${formatMoney(b.balance)}</td></tr>`).join("")}
      </tbody>
    </table>
  `;
}

function renderMovementsTable(state) {
  const search = ($("mvSearch")?.value || "").trim().toLowerCase();
  const typeFilter = $("mvFilterType")?.value || "ALL";
  let rows = [...state.movements];

  if (search) {
    rows = rows.filter(r =>
      r.type.toLowerCase().includes(search) ||
      r.detail.toLowerCase().includes(search) ||
      r.responsible.toLowerCase().includes(search) ||
      getBranchName(state, r.branchId).toLowerCase().includes(search)
    );
  }

  if (typeFilter !== "ALL") rows = rows.filter(r => r.type === typeFilter);

  $("movementsTableWrap").innerHTML = `
    <table>
      <thead>
        <tr>
          <th>Fecha</th><th>Tipo</th><th>Sucursal</th><th>Caja</th><th>Canal</th><th>Responsable</th><th>Detalle</th><th class="right">Monto</th>
        </tr>
      </thead>
      <tbody>
        ${rows.length ? rows.map(r => `
          <tr>
            <td>${new Date(r.date).toLocaleString("es-DO")}</td>
            <td>${r.type}</td>
            <td>${getBranchName(state, r.branchId)}</td>
            <td>${getBoxName(state, r.boxId)}</td>
            <td>${r.channel}</td>
            <td>${r.responsible}</td>
            <td>${r.detail}</td>
            <td class="right">${formatMoney(r.amount)}</td>
          </tr>
        `).join("") : `<tr><td colspan="8">Sin movimientos registrados.</td></tr>`}
      </tbody>
    </table>
  `;
}

function renderTreasuryTable(state) {
  $("treasuryTableWrap").innerHTML = `
    <table>
      <thead><tr><th>Fecha</th><th>Tipo</th><th>Sucursal</th><th>Detalle</th><th class="right">Monto</th><th>Estado</th></tr></thead>
      <tbody>
        ${state.treasury.length ? state.treasury.map(t => `
          <tr>
            <td>${new Date(t.date).toLocaleString("es-DO")}</td>
            <td>${t.kind}</td>
            <td>${getBranchName(state, t.branchId)}</td>
            <td>${t.detail}</td>
            <td class="right">${formatMoney(t.amount)}</td>
            <td>${t.status}</td>
          </tr>
        `).join("") : `<tr><td colspan="6">Sin solicitudes ni remesas.</td></tr>`}
      </tbody>
    </table>
  `;
}

function renderUsersTable(state) {
  $("usersTableWrap").innerHTML = `
    <table>
      <thead><tr><th>Nombre</th><th>Usuario</th><th>Rol</th><th>Sucursal</th><th>Estado</th></tr></thead>
      <tbody>
        ${state.users.map(u => `<tr><td>${u.name}</td><td>${u.username}</td><td>${u.role}</td><td>${getBranchName(state, u.branchId)}</td><td>${u.active ? "Activo" : "Inactivo"}</td></tr>`).join("")}
      </tbody>
    </table>
  `;
}

function renderAuditTable(state) {
  const q = ($("auditSearch")?.value || "").trim().toLowerCase();
  let rows = [...state.audit];

  if (q) {
    rows = rows.filter(r =>
      r.user.toLowerCase().includes(q) ||
      r.role.toLowerCase().includes(q) ||
      r.action.toLowerCase().includes(q) ||
      r.detail.toLowerCase().includes(q)
    );
  }

  $("auditTableWrap").innerHTML = `
    <table>
      <thead><tr><th>Fecha</th><th>Usuario</th><th>Rol</th><th>Acci�n</th><th>Detalle</th></tr></thead>
      <tbody>
        ${rows.length ? rows.map(r => `
          <tr>
            <td>${new Date(r.date).toLocaleString("es-DO")}</td>
            <td>${r.user}</td>
            <td>${r.role}</td>
            <td>${r.action}</td>
            <td>${r.detail}</td>
          </tr>
        `).join("") : `<tr><td colspan="5">Sin resultados.</td></tr>`}
      </tbody>
    </table>
  `;
}

function renderDashboard(state) {
  const cashTotal = state.branches.reduce((acc, b) => acc + b.cash, 0);
  const avgCash = state.boxes.length ? state.boxes.reduce((acc, b) => acc + b.balance, 0) / state.boxes.length : 0;
  const today = new Date().toDateString();
  const txToday = state.movements.filter(m => new Date(m.date).toDateString() === today).length;
  const openBoxes = state.boxes.filter(b => b.status === "Abierta").length;
  const alerts = computeAlerts(state).length;
  const recentOps = Math.min(state.movements.length + state.treasury.length, 10);
  const activeUsers = state.users.filter(u => u.active).length;

  $("kpiCashTotal").textContent = formatMoney(cashTotal);
  $("kpiAvgCash").textContent = formatMoney(avgCash);
  $("kpiTxCount").textContent = String(txToday);
  $("kpiAlerts").textContent = String(alerts);
  $("kpiOpenBoxes").textContent = String(openBoxes);
  $("kpiUsers").textContent = String(activeUsers);
  $("kpiRecentOps").textContent = String(recentOps);

  renderBranchBars(state);
  renderAlerts(state);
  renderRecentOps(state);
}

function renderHeader(state) {
  const session = loadSession();
  const currentUser = getCurrentUser(state);
  const logged = !!session && !!currentUser;

  $("viewLogin").classList.toggle("hidden", logged);
  $("viewApp").classList.toggle("hidden", !logged);
  $("btnLogout").classList.toggle("hidden", !logged);
  $("sessionBadge").classList.toggle("hidden", !logged);

  if (logged) {
    $("sessionBadge").textContent = `${session.username} � ${session.role}`;
    $("userDisplay").textContent = `${currentUser.name} � ${currentUser.role}`;
  }
}

function render() {
  const state = ensureState();
  renderHeader(state);

  const session = loadSession();
  if (!session) {
    const remembered = getRememberedUser();
    if (remembered) {
      $("loginUser").value = remembered;
      $("rememberUser").checked = true;
    }
    return;
  }

  updateBranchSelects(state);

  document.querySelectorAll(".nav-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.tab === state.settings.currentTab);
  });
  document.querySelectorAll(".tab-panel").forEach(panel => {
    panel.classList.toggle("hidden", panel.dataset.panel !== state.settings.currentTab);
  });

  renderDashboard(state);
  renderBranchesTable(state);
  renderBoxesTable(state);
  renderMovementsTable(state);
  renderTreasuryTable(state);
  renderUsersTable(state);
  renderAuditTable(state);
}

function login() {
  hideMessages();
  const state = ensureState();
  const username = $("loginUser").value.trim();
  const password = $("loginPass").value.trim();
  const role = $("loginRole").value;
  const user = state.users.find(u => u.username === username);

  if (!user) return showLoginMsg("Usuario no encontrado.");
  if (user.password !== password) return showLoginMsg("Contrase�a incorrecta.");

  saveSession({ username: user.username, role });
  if ($("rememberUser").checked) setRememberedUser(username);
  else clearRememberedUser();

  addAudit(state, "Inicio de sesi�n", `Acceso al sistema con rol visual ${role}`);
  saveState(state);
  render();
}

function logout() {
  const state = ensureState();
  addAudit(state, "Cierre de sesi�n", "Salida del sistema");
  saveState(state);
  clearSession();
  render();
}

function addBranch() {
  const state = ensureState();
  const name = $("branchName").value.trim();
  const zone = $("branchZone").value.trim();
  const cash = parseAmount($("branchCash").value);

  if (!name || !zone || !Number.isFinite(cash) || cash < 0) return;

  state.branches.push({ id: uid(), name, zone, cash });
  addAudit(state, "Registro de sucursal", `${name} (${zone}) con efectivo inicial ${formatMoney(cash)}`);
  saveState(state);

  $("branchName").value = "";
  $("branchZone").value = "";
  $("branchCash").value = "";
  render();
}

function addBox() {
  const state = ensureState();
  const branchId = $("boxBranch").value;
  const name = $("boxName").value.trim();
  const responsible = $("boxResponsible").value.trim();
  const balance = parseAmount($("boxCash").value);

  if (!branchId || !name || !responsible || !Number.isFinite(balance) || balance < 0) return;

  state.boxes.push({
    id: uid(),
    branchId,
    name,
    responsible,
    balance,
    status: "Cerrada"
  });

  addAudit(state, "Registro de caja", `${name} en ${getBranchName(state, branchId)} asignada a ${responsible}`);
  saveState(state);

  $("boxName").value = "";
  $("boxResponsible").value = "";
  $("boxCash").value = "";
  render();
}

function addMovement(simulateAlert = false) {
  hideMessages();
  const state = ensureState();

  const type = $("mvType").value;
  const branchId = $("mvBranch").value;
  const boxId = $("mvBox").value;
  const channel = $("mvChannel").value;
  const amount = parseAmount($("mvAmount").value);
  const responsible = $("mvResponsible").value.trim();
  const detail = $("mvDetail").value.trim();

  if (!branchId || !boxId || !Number.isFinite(amount) || amount <= 0 || !responsible || !detail) {
    return showMovementMsg("Completa todos los campos correctamente.", "err");
  }

  const branch = state.branches.find(b => b.id === branchId);
  const box = state.boxes.find(b => b.id === boxId);
  if (!branch || !box) return showMovementMsg("Sucursal o caja inv�lida.", "err");

  let alert = "";
  if (simulateAlert || amount > 100000) {
    alert = `L�mite excedido en ${box.name} por operaci�n de ${formatMoney(amount)}.`;
  }

  if (type === "Deposito" || type === "Reabastecimiento") {
    branch.cash += amount;
    box.balance += amount;
  } else if (type === "Retiro") {
    branch.cash -= amount;
    box.balance -= amount;
  } else if (type === "Transferencia Interna") {
    branch.cash += amount;
  }

  state.movements.unshift({
    id: uid(),
    date: nowISO(),
    type,
    branchId,
    boxId,
    channel,
    amount,
    responsible,
    detail,
    alert
  });

  addAudit(state, "Registro de movimiento", `${type} por ${formatMoney(amount)} en ${box.name} - ${branch.name}`);
  saveState(state);

  $("mvAmount").value = "";
  $("mvResponsible").value = "";
  $("mvDetail").value = "";

  showMovementMsg("Movimiento registrado correctamente.", "ok");
  render();
}

function requestFunds() {
  const state = ensureState();
  const branchId = $("fundBranch").value;
  const amount = parseAmount($("fundAmount").value);
  const reason = $("fundReason").value.trim();

  if (!branchId || !Number.isFinite(amount) || amount <= 0 || !reason) return;

  state.treasury.unshift({
    id: uid(),
    date: nowISO(),
    kind: "Solicitud de fondos",
    branchId,
    amount,
    detail: reason,
    status: "Pendiente"
  });

  addAudit(state, "Solicitud de fondos", `${getBranchName(state, branchId)} solicita ${formatMoney(amount)} por ${reason}`);
  saveState(state);

  $("fundAmount").value = "";
  $("fundReason").value = "";
  render();
}

function createRemittance() {
  const state = ensureState();
  const branchId = $("remBranch").value;
  const amount = parseAmount($("remAmount").value);
  const destination = $("remDestination").value.trim();

  if (!branchId || !Number.isFinite(amount) || amount <= 0 || !destination) return;

  const branch = state.branches.find(b => b.id === branchId);
  if (!branch) return;
  branch.cash -= amount;

  state.treasury.unshift({
    id: uid(),
    date: nowISO(),
    kind: "Remesa",
    branchId,
    amount,
    detail: `Destino: ${destination}`,
    status: "Programada"
  });

  addAudit(state, "Programaci�n de remesa", `${getBranchName(state, branchId)} programa remesa de ${formatMoney(amount)} hacia ${destination}`);
  saveState(state);

  $("remAmount").value = "";
  $("remDestination").value = "";
  render();
}

function addUser() {
  const state = ensureState();
  const name = $("newUserName").value.trim();
  const username = $("newUsername").value.trim();
  const role = $("newUserRole").value;
  const branchId = $("newUserBranch").value;

  if (!name || !username || !branchId) return;
  if (state.users.some(u => u.username === username)) return;

  state.users.push({
    id: uid(),
    name,
    username,
    password: "123",
    role,
    branchId,
    active: true
  });

  addAudit(state, "Registro de usuario", `${name} (${username}) con rol ${role}`);
  saveState(state);

  $("newUserName").value = "";
  $("newUsername").value = "";
  render();
}

function openModal(mode) {
  modalMode = mode;
  $("modal").classList.remove("hidden");
  $("modalTitle").textContent = mode === "open" ? "Apertura de caja" : "Cierre de caja";
  $("modalHint").textContent = mode === "open"
    ? "Registra el efectivo inicial de apertura."
    : "Registra el valor final para cierre o arqueo.";
  $("modalAmount").value = "";
  $("modalDetail").value = "";
  render();
}

function closeModal() {
  $("modal").classList.add("hidden");
  modalMode = null;
}

function confirmModalAction() {
  const state = ensureState();
  const branchId = $("modalBranch").value;
  const boxId = $("modalBox").value;
  const amount = parseAmount($("modalAmount").value);
  const detail = $("modalDetail").value.trim() || (modalMode === "open" ? "Apertura operativa" : "Cierre operativo");

  if (!branchId || !boxId || !Number.isFinite(amount) || amount < 0) return;

  const box = state.boxes.find(b => b.id === boxId);
  const branch = state.branches.find(b => b.id === branchId);
  if (!box || !branch) return;

  if (modalMode === "open") {
    box.status = "Abierta";
    box.balance = amount;
    addAudit(state, "Apertura de caja", `${box.name} abierta con ${formatMoney(amount)} en ${branch.name}`);
  } else {
    box.status = "Cerrada";
    box.balance = amount;
    addAudit(state, "Cierre de caja", `${box.name} cerrada con ${formatMoney(amount)} en ${branch.name}`);
  }

  state.movements.unshift({
    id: uid(),
    date: nowISO(),
    type: modalMode === "open" ? "Apertura" : "Cierre",
    branchId,
    boxId,
    channel: "Efectivo",
    amount,
    responsible: loadSession()?.username || "Sistema",
    detail
  });

  saveState(state);
  closeModal();
  render();
}

function exportAudit() {
  const state = ensureState();
  const rows = [["Fecha","Usuario","Rol","Accion","Detalle"]];
  state.audit.forEach(a => {
    rows.push([
      new Date(a.date).toLocaleString("es-DO"),
      a.user,
      a.role,
      a.action,
      a.detail
    ]);
  });

  const csv = rows.map(r => r.map(v => `"${String(v).replaceAll('"', '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "auditoria_banco_la_tendencia.csv";
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function seedDemoData() {
  const state = ensureState();

  const demoMoves = [
    { type: "Deposito", branchId: "b1", boxId: "x1", channel: "Efectivo", amount: 18000, responsible: "Laura P�rez", detail: "Ingreso de efectivo por ventanilla" },
    { type: "Retiro", branchId: "b2", boxId: "x3", channel: "Efectivo", amount: 12000, responsible: "Carlos N��ez", detail: "Retiro autorizado" },
    { type: "Reabastecimiento", branchId: "b3", boxId: "x6", channel: "Efectivo", amount: 25000, responsible: "Pedro Lara", detail: "Reabastecimiento de caja" },
    { type: "Arqueo", branchId: "b1", boxId: "x2", channel: "Efectivo", amount: 0, responsible: "Julio Mart�nez", detail: "Arqueo sin diferencias" }
  ];

  demoMoves.forEach((m, i) => {
    state.movements.unshift({
      id: uid(),
      date: new Date(Date.now() - i * 86400000).toISOString(),
      ...m
    });
  });

  state.treasury.unshift({
    id: uid(),
    date: nowISO(),
    kind: "Solicitud de fondos",
    branchId: "b2",
    amount: 90000,
    detail: "Incremento de demanda operativa",
    status: "Pendiente"
  });

  state.treasury.unshift({
    id: uid(),
    date: nowISO(),
    kind: "Remesa",
    branchId: "b1",
    amount: 60000,
    detail: "Destino: Tesorer�a central",
    status: "Programada"
  });

  addAudit(state, "Carga demo", "Se agregaron movimientos y tesorer�a de ejemplo");
  saveState(state);
  render();
}

function resetSystem() {
  localStorage.removeItem(LS.state);
  localStorage.removeItem(LS.session);
  localStorage.removeItem(LS.remembered);
  hideMessages();
  render();
}

document.addEventListener("click", (e) => {
  const nav = e.target.closest(".nav-btn");
  if (nav) setTab(nav.dataset.tab);
});

$("btnLogin").addEventListener("click", login);
$("loginPass").addEventListener("keydown", (e) => {
  if (e.key === "Enter") login();
});

$("btnTogglePass").addEventListener("click", () => {
  const input = $("loginPass");
  input.type = input.type === "password" ? "text" : "password";
});

$("btnForgot").addEventListener("click", () => {
  showLoginMsg("Credenciales demo: Julio / 123", "ok");
});

$("btnLogout").addEventListener("click", logout);
$("btnAddBranch").addEventListener("click", addBranch);
$("btnAddBox").addEventListener("click", addBox);
$("btnAddMovement").addEventListener("click", () => addMovement(false));
$("btnSimulateLimit").addEventListener("click", () => addMovement(true));
$("btnRequestFunds").addEventListener("click", requestFunds);
$("btnCreateRemittance").addEventListener("click", createRemittance);
$("btnAddUser").addEventListener("click", addUser);

$("btnOpenCash").addEventListener("click", () => openModal("open"));
$("btnCloseCash").addEventListener("click", () => openModal("close"));
$("btnCancelModal").addEventListener("click", closeModal);
$("btnConfirmModal").addEventListener("click", confirmModalAction);

$("btnExportAudit").addEventListener("click", exportAudit);
$("btnSeedDemo").addEventListener("click", seedDemoData);
$("btnResetSystem").addEventListener("click", resetSystem);

$("mvSearch").addEventListener("input", render);
$("mvFilterType").addEventListener("change", render);
$("auditSearch").addEventListener("input", render);

$("mvBranch").addEventListener("change", () => updateBoxSelects(ensureState()));
$("modalBranch").addEventListener("change", () => updateBoxSelects(ensureState()));

(function init() {
  ensureState();
  const remembered = getRememberedUser();
  if (remembered) {
    $("loginUser").value = remembered;
    $("rememberUser").checked = true;
  }
  render();
})();
