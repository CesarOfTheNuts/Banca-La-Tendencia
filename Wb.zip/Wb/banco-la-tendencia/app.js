﻿const $ = (id) => document.getElementById(id);

const LS = { state:"blt_cash_mgmt_state_v3", session:"blt_cash_mgmt_session_v3", remembered:"blt_cash_mgmt_remembered_v3" };
const ROLE_LIMITS = { Cajero:50000, Supervisor:150000, Gerente:1000000, Auditor:0 };
const TAB_ACCESS = {
  dashboard:["Cajero","Supervisor","Gerente","Auditor"],
  branches:["Supervisor","Gerente","Auditor"],
  movements:["Cajero","Supervisor","Gerente","Auditor"],
  treasury:["Cajero","Supervisor","Gerente","Auditor"],
  users:["Gerente","Auditor"],
  audit:["Supervisor","Gerente","Auditor"]
};

let modalMode = null;

function formatMoney(v){return new Intl.NumberFormat("es-DO",{style:"currency",currency:"DOP",maximumFractionDigits:2}).format(v||0)}
function nowISO(){return new Date().toISOString()}
function parseAmount(v){const n=Number(String(v||"").replaceAll(",","").trim());return Number.isFinite(n)?n:NaN}
function uid(){return crypto.randomUUID?.()||("id_"+Math.random().toString(16).slice(2))}
function saveState(s){localStorage.setItem(LS.state,JSON.stringify(s))}
function loadState(){const r=localStorage.getItem(LS.state); if(!r)return null; try{return JSON.parse(r)}catch{return null}}
function saveSession(s){localStorage.setItem(LS.session,JSON.stringify(s))}
function loadSession(){const r=localStorage.getItem(LS.session); if(!r)return null; try{return JSON.parse(r)}catch{return null}}
function clearSession(){localStorage.removeItem(LS.session)}
function setRememberedUser(v){localStorage.setItem(LS.remembered,v)}
function getRememberedUser(){return localStorage.getItem(LS.remembered)||""}
function clearRememberedUser(){localStorage.removeItem(LS.remembered)}

function getInitialState(){
  return {
    users:[
      {id:uid(),name:"Julio Martínez",username:"Julio",password:"123",role:"Gerente",branchId:"b1",active:true,limit:ROLE_LIMITS.Gerente},
      {id:uid(),name:"Laura Pérez",username:"lperez",password:"123",role:"Supervisor",branchId:"b1",active:true,limit:ROLE_LIMITS.Supervisor},
      {id:uid(),name:"Carlos Núñez",username:"cnunez",password:"123",role:"Cajero",branchId:"b2",active:true,limit:ROLE_LIMITS.Cajero},
      {id:uid(),name:"María Gómez",username:"mgomez",password:"123",role:"Auditor",branchId:"b3",active:true,limit:ROLE_LIMITS.Auditor}
    ],
    branches:[
      {id:"b1",name:"Sucursal Central",zone:"Distrito Nacional",cash:450000},
      {id:"b2",name:"Sucursal Santiago",zone:"Norte",cash:320000},
      {id:"b3",name:"Sucursal Punta Cana",zone:"Este",cash:210000}
    ],
    boxes:[
      {id:"x1",branchId:"b1",name:"Caja 01",responsible:"Laura Pérez",balance:65000,status:"Abierta"},
      {id:"x2",branchId:"b1",name:"Caja 02",responsible:"Ricardo Peña",balance:50000,status:"Cerrada"},
      {id:"x3",branchId:"b2",name:"Caja 03",responsible:"Carlos Núñez",balance:42000,status:"Abierta"},
      {id:"x4",branchId:"b2",name:"Caja 04",responsible:"Diana Ruiz",balance:36000,status:"Abierta"},
      {id:"x5",branchId:"b3",name:"Caja 05",responsible:"Esther Díaz",balance:28000,status:"Cerrada"},
      {id:"x6",branchId:"b3",name:"Caja 06",responsible:"Pedro Lara",balance:31000,status:"Abierta"}
    ],
    movements:[],
    treasury:[],
    audit:[],
    settings:{currentTab:"dashboard"}
  }
}

function ensureState(){
  let s=loadState();
  if(!s){
    s=getInitialState();
    addAudit(s,"Sistema inicializado","Carga inicial del entorno demo");
    saveState(s);
  }
  return s;
}

function addAudit(state,action,detail){
  const session=loadSession();
  state.audit.unshift({
    id:uid(),
    date:nowISO(),
    user:session?.username||"Sistema",
    role:session?.role||"Sistema",
    action,detail
  });
}

function getBranchName(state,id){return state.branches.find(b=>b.id===id)?.name||"—"}
function getBoxName(state,id){return state.boxes.find(b=>b.id===id)?.name||"—"}
function getCurrentUser(state){const session=loadSession(); if(!session)return null; return state.users.find(u=>u.username===session.username)||null}

function showLoginMsg(text,type="err"){
  const el=$("loginMsg"); if(!el)return;
  el.textContent=text; el.classList.remove("hidden","ok","err"); el.classList.add(type==="ok"?"ok":"err");
}
function showMovementMsg(text,type="ok"){
  const el=$("movementMsg"); if(!el)return;
  el.textContent=text; el.classList.remove("hidden","ok","err"); el.classList.add(type==="ok"?"ok":"err");
}
function hideMessages(){
  ["loginMsg","movementMsg"].forEach(id=>{
    const el=$(id); if(!el)return;
    el.classList.add("hidden"); el.textContent=""; el.classList.remove("ok","err");
  });
}

function filterRowsByRole(rows,state,currentUser,fieldBranch="branchId"){
  if(!currentUser) return [];
  if(currentUser.role==="Gerente"||currentUser.role==="Auditor") return rows;
  if(currentUser.role==="Supervisor"||currentUser.role==="Cajero"){
    return rows.filter(r=>r[fieldBranch]===currentUser.branchId);
  }
  return [];
}

function allowedTabsForRole(role){
  return Object.entries(TAB_ACCESS).filter(([,roles])=>roles.includes(role)).map(([tab])=>tab);
}

function enforceTabAccess(state,currentUser){
  if(!currentUser) return;
  const allowed=allowedTabsForRole(currentUser.role);
  document.querySelectorAll(".nav-btn").forEach(btn=>{
    btn.classList.toggle("hidden",!allowed.includes(btn.dataset.tab));
  });
  if(!allowed.includes(state.settings.currentTab)){
    state.settings.currentTab="dashboard";
    saveState(state);
  }
}

function enforceSectionVisibility(currentUser){
  document.querySelectorAll(".role-cajero,.role-supervisor,.role-gerente,.role-auditor").forEach(el=>{
    const allow =
      (el.classList.contains("role-cajero") && currentUser.role==="Cajero") ||
      (el.classList.contains("role-supervisor") && currentUser.role==="Supervisor") ||
      (el.classList.contains("role-gerente") && currentUser.role==="Gerente") ||
      (el.classList.contains("role-auditor") && currentUser.role==="Auditor") ||
      (currentUser.role==="Gerente" && (el.classList.contains("role-supervisor")||el.classList.contains("role-cajero"))) ||
      (currentUser.role==="Supervisor" && el.classList.contains("role-cajero"));
    el.classList.toggle("hidden",!allow);
  });
}

function updateZoneFilter(state,currentUser){
  const el=$("branchZoneFilter"); if(!el)return;
  const zones=[...new Set(state.branches.filter(b=>{
    if(currentUser.role==="Gerente"||currentUser.role==="Auditor") return true;
    return b.id===currentUser.branchId;
  }).map(b=>b.zone))];
  const cur=el.value||"ALL";
  el.innerHTML=`<option value="ALL">Todas</option>`+zones.map(z=>`<option value="${z}">${z}</option>`).join("");
  el.value=zones.includes(cur)||cur==="ALL"?cur:"ALL";
}

function updateBoxSelects(state,currentUser){
  const mvBranch=$("mvBranch")?.value || currentUser.branchId || state.branches[0]?.id;
  const modalBranch=$("modalBranch")?.value || currentUser.branchId || state.branches[0]?.id;

  const fill=(selectId,branchId)=>{
    const el=$(selectId); if(!el)return;
    let filtered=state.boxes.filter(b=>b.branchId===branchId);
    el.innerHTML=filtered.map(b=>`<option value="${b.id}">${b.name}</option>`).join("");
  };
  fill("mvBox",mvBranch);
  fill("modalBox",modalBranch);
}

function updateBranchSelects(state,currentUser){
  const roleBranches=state.branches.filter(b=>{
    if(currentUser.role==="Gerente"||currentUser.role==="Auditor") return true;
    return b.id===currentUser.branchId;
  });
  ["boxBranch","mvBranch","fundBranch","remBranch","newUserBranch","modalBranch"].forEach(id=>{
    const el=$(id); if(!el)return;
    const cur=el.value;
    const allowed=(id==="newUserBranch" && currentUser.role!=="Gerente") ? [] : roleBranches;
    el.innerHTML=allowed.map(b=>`<option value="${b.id}">${b.name}</option>`).join("");
    if(allowed.some(b=>b.id===cur)) el.value=cur;
  });
  updateBoxSelects(state,currentUser);
  updateZoneFilter(state,currentUser);
}

function setTab(tab){
  const state=ensureState(), currentUser=getCurrentUser(state);
  if(!currentUser) return;
  if(!allowedTabsForRole(currentUser.role).includes(tab)) return;
  state.settings.currentTab=tab;
  saveState(state);
  render();
}
function renderBranchBars(state,currentUser){
  const wrap=$("branchBars"); if(!wrap)return; wrap.innerHTML="";
  let branches=[...state.branches];
  if(currentUser.role==="Supervisor"||currentUser.role==="Cajero") branches=branches.filter(b=>b.id===currentUser.branchId);
  const entries=branches.map(b=>({name:b.name,value:b.cash}));
  const max=Math.max(...entries.map(e=>e.value),1);
  entries.forEach(entry=>{
    const pct=Math.round((entry.value/max)*100);
    wrap.insertAdjacentHTML("beforeend",`
      <div class="bar-row">
        <div class="bar-name">${entry.name}</div>
        <div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div>
        <div class="bar-value">${formatMoney(entry.value)}</div>
      </div>
    `);
  });
}

function computeAlerts(state,currentUser){
  const alerts=[];
  let boxes=[...state.boxes];
  if(currentUser.role==="Supervisor"||currentUser.role==="Cajero") boxes=boxes.filter(b=>b.branchId===currentUser.branchId);
  boxes.forEach(box=>{
    if(box.balance>70000) alerts.push({level:"rojo",text:`${box.name} excede el umbral de caja con ${formatMoney(box.balance)}.`});
    if(box.status==="Abierta" && box.balance<10000) alerts.push({level:"amarillo",text:`${box.name} tiene bajo efectivo disponible.`});
  });
  filterRowsByRole([...state.movements],state,currentUser).slice(0,25).forEach(mv=>{
    if(mv.alert) alerts.push({level:"rojo",text:mv.alert});
  });
  return alerts.slice(0,10);
}

function renderAlerts(state,currentUser){
  const list=$("alertsList"); if(!list)return; list.innerHTML="";
  const alerts=computeAlerts(state,currentUser);
  if(!alerts.length){list.innerHTML=`<div class="list-item">Sin alertas activas.</div>`; return}
  alerts.forEach(a=>{
    const cls=a.level==="rojo"?"badge-danger":"badge-warn";
    list.insertAdjacentHTML("beforeend",`<div class="list-item"><span class="${cls}">${a.level.toUpperCase()}</span><br>${a.text}</div>`);
  });
}

function renderRecentOps(state,currentUser){
  const list=$("recentOpsList"); if(!list)return; list.innerHTML="";
  const recentMovs=filterRowsByRole([...state.movements],state,currentUser).slice(0,6).map(m=>({
    title:m.type,text:`${m.detail} · ${m.responsible} · ${new Date(m.date).toLocaleString("es-DO")}`
  }));
  const recentTreas=filterRowsByRole([...state.treasury],state,currentUser).slice(0,3).map(t=>({
    title:t.kind,text:`${t.detail} · ${new Date(t.date).toLocaleString("es-DO")}`
  }));
  const recent=[...recentMovs,...recentTreas].slice(0,8);
  if(!recent.length){list.innerHTML=`<div class="list-item">No hay operaciones registradas.</div>`; return}
  recent.forEach(op=>list.insertAdjacentHTML("beforeend",`<div class="list-item"><b>${op.title}</b><br>${op.text}</div>`));
}

function filterByDateRange(rows,fromId,toId,dateField="date"){
  const from=$(fromId)?.value ? new Date($(fromId).value+"T00:00:00") : null;
  const to=$(toId)?.value ? new Date($(toId).value+"T23:59:59") : null;
  return rows.filter(r=>{
    const d=new Date(r[dateField]);
    if(from && d<from) return false;
    if(to && d>to) return false;
    return true;
  });
}

function renderBranchesTable(state,currentUser){
  const zoneFilter=$("branchZoneFilter")?.value || "ALL";
  let rows=[...state.branches];
  if(currentUser.role==="Supervisor"||currentUser.role==="Cajero") rows=rows.filter(b=>b.id===currentUser.branchId);
  if(zoneFilter!=="ALL") rows=rows.filter(b=>b.zone===zoneFilter);
  $("branchesTableWrap").innerHTML=`
    <table>
      <thead><tr><th>Sucursal</th><th>Zona</th><th class="right">Efectivo disponible</th></tr></thead>
      <tbody>
        ${rows.map(b=>`<tr><td>${b.name}</td><td>${b.zone}</td><td class="right">${formatMoney(b.cash)}</td></tr>`).join("")}
      </tbody>
    </table>
  `;
}

function renderBoxesTable(state,currentUser){
  const responsibleFilter=($("boxResponsibleFilter")?.value||"").trim().toLowerCase();
  let rows=[...state.boxes];
  if(currentUser.role==="Supervisor"||currentUser.role==="Cajero") rows=rows.filter(b=>b.branchId===currentUser.branchId);
  if(responsibleFilter) rows=rows.filter(b=>b.responsible.toLowerCase().includes(responsibleFilter));
  $("boxesTableWrap").innerHTML=`
    <table>
      <thead><tr><th>Caja</th><th>Sucursal</th><th>Responsable</th><th>Estado</th><th class="right">Saldo</th></tr></thead>
      <tbody>
        ${rows.map(b=>`<tr><td>${b.name}</td><td>${getBranchName(state,b.branchId)}</td><td>${b.responsible}</td><td>${b.status}</td><td class="right">${formatMoney(b.balance)}</td></tr>`).join("")}
      </tbody>
    </table>
  `;
}

function renderMovementsTable(state,currentUser){
  const search=($("mvSearch")?.value||"").trim().toLowerCase();
  const typeFilter=$("mvFilterType")?.value || "ALL";
  let rows=filterRowsByRole([...state.movements],state,currentUser);
  rows=filterByDateRange(rows,"mvDateFrom","mvDateTo");
  if(search){
    rows=rows.filter(r=>
      r.type.toLowerCase().includes(search) ||
      r.detail.toLowerCase().includes(search) ||
      r.responsible.toLowerCase().includes(search) ||
      getBranchName(state,r.branchId).toLowerCase().includes(search)
    );
  }
  if(typeFilter!=="ALL") rows=rows.filter(r=>r.type===typeFilter);
  $("movementsTableWrap").innerHTML=`
    <table>
      <thead><tr><th>Fecha</th><th>Tipo</th><th>Sucursal</th><th>Caja</th><th>Canal</th><th>Responsable</th><th>Detalle</th><th class="right">Monto</th></tr></thead>
      <tbody>
        ${rows.length ? rows.map(r=>`
          <tr>
            <td>${new Date(r.date).toLocaleString("es-DO")}</td>
            <td>${r.type}</td>
            <td>${getBranchName(state,r.branchId)}</td>
            <td>${getBoxName(state,r.boxId)}</td>
            <td>${r.channel}</td>
            <td>${r.responsible}</td>
            <td>${r.detail}</td>
            <td class="right">${formatMoney(r.amount)}</td>
          </tr>
        `).join("") : `<tr><td colspan="8">Sin movimientos registrados.</td></tr>`}
      </tbody>
    </table>
  `;
}
function renderTreasuryTable(state,currentUser){
  const rows=filterRowsByRole([...state.treasury],state,currentUser);
  $("treasuryTableWrap").innerHTML=`
    <table>
      <thead><tr><th>Fecha</th><th>Tipo</th><th>Sucursal</th><th>Detalle</th><th class="right">Monto</th><th>Estado</th></tr></thead>
      <tbody>
        ${rows.length ? rows.map(t=>`
          <tr>
            <td>${new Date(t.date).toLocaleString("es-DO")}</td>
            <td>${t.kind}</td>
            <td>${getBranchName(state,t.branchId)}</td>
            <td>${t.detail}</td>
            <td class="right">${formatMoney(t.amount)}</td>
            <td>${t.status}</td>
          </tr>
        `).join("") : `<tr><td colspan="6">Sin solicitudes ni remesas.</td></tr>`}
      </tbody>
    </table>
  `;
  renderFundApprovals(state,currentUser);
  renderBalanceReports(state,currentUser);
}

function renderFundApprovals(state,currentUser){
  const wrap=$("fundApprovalWrap"); if(!wrap)return; wrap.innerHTML="";
  if(!(currentUser.role==="Supervisor"||currentUser.role==="Gerente")){
    wrap.innerHTML=`<div class="list-item">No tienes permisos para aprobar fondos.</div>`; return;
  }
  let pending=state.treasury.filter(t=>t.kind==="Solicitud de fondos" && t.status==="Pendiente");
  if(currentUser.role==="Supervisor") pending=pending.filter(t=>t.branchId===currentUser.branchId);
  if(!pending.length){wrap.innerHTML=`<div class="list-item">No hay solicitudes pendientes.</div>`; return}
  pending.forEach(req=>{
    wrap.insertAdjacentHTML("beforeend",`
      <div class="list-item">
        <b>${getBranchName(state,req.branchId)}</b><br>
        ${req.detail}<br>
        <span class="badge-warn">Pendiente</span>
        <div class="action-inline section-gap">
          <button class="btn primary approve-fund" data-id="${req.id}" type="button">Aprobar</button>
          <button class="btn ghost reject-fund" data-id="${req.id}" type="button">Rechazar</button>
        </div>
      </div>
    `);
  });
}

function renderBalanceReports(state,currentUser){
  const wrap=$("balanceReportsWrap"); if(!wrap)return;
  let rows=filterRowsByRole([...state.movements],state,currentUser);
  const today=new Date();
  const weekAgo=new Date(Date.now()-7*86400000);
  const monthAgo=new Date(Date.now()-30*86400000);
  const daily=rows.filter(m=>new Date(m.date).toDateString()===today.toDateString());
  const weekly=rows.filter(m=>new Date(m.date)>=weekAgo);
  const monthly=rows.filter(m=>new Date(m.date)>=monthAgo);
  const calcNet=(items)=>items.reduce((acc,m)=>{
    if(m.type==="Retiro") return acc-m.amount;
    if(m.type==="Depósito" || m.type==="Reabastecimiento") return acc+m.amount;
    return acc;
  },0);
  wrap.innerHTML=`
    <div class="mini-grid">
      <div class="mini-card"><div class="title">Balance del día</div><div class="value">${formatMoney(calcNet(daily))}</div></div>
      <div class="mini-card"><div class="title">Balance de la semana</div><div class="value">${formatMoney(calcNet(weekly))}</div></div>
      <div class="mini-card"><div class="title">Balance del mes</div><div class="value">${formatMoney(calcNet(monthly))}</div></div>
    </div>
  `;
}

function renderCashTrends(state,currentUser){
  const wrap=$("cashTrendWrap"); if(!wrap)return;
  const rows=filterRowsByRole([...state.movements],state,currentUser);
  const byDay={};
  rows.forEach(m=>{
    const key=new Date(m.date).toLocaleDateString("es-DO");
    if(!byDay[key]) byDay[key]={in:0,out:0};
    if(m.type==="Retiro") byDay[key].out+=m.amount;
    if(m.type==="Depósito" || m.type==="Reabastecimiento") byDay[key].in+=m.amount;
  });
  const entries=Object.entries(byDay).slice(-7);
  if(!entries.length){wrap.innerHTML=`<div class="list-item">No hay suficientes datos históricos todavía.</div>`; return}
  wrap.innerHTML=entries.map(([day,vals])=>`
    <div class="list-item"><b>${day}</b><br>Entradas: ${formatMoney(vals.in)}<br>Salidas: ${formatMoney(vals.out)}</div>
  `).join("");
}

function renderUsersTable(state,currentUser){
  let rows=[...state.users];
  if(currentUser.role==="Supervisor") rows=rows.filter(u=>u.branchId===currentUser.branchId);
  if(currentUser.role==="Cajero") rows=rows.filter(u=>u.username===currentUser.username);
  $("usersTableWrap").innerHTML=`
    <table>
      <thead><tr><th>Nombre</th><th>Usuario</th><th>Rol</th><th>Límite</th><th>Sucursal</th><th>Estado</th></tr></thead>
      <tbody>
        ${rows.map(u=>`<tr><td>${u.name}</td><td>${u.username}</td><td>${u.role}</td><td>${formatMoney(u.limit || ROLE_LIMITS[u.role] || 0)}</td><td>${getBranchName(state,u.branchId)}</td><td>${u.active?"Activo":"Inactivo"}</td></tr>`).join("")}
      </tbody>
    </table>
  `;
}

function renderAuditTable(state,currentUser){
  const q=($("auditSearch")?.value||"").trim().toLowerCase();
  let rows=[...state.audit];
  if(currentUser.role==="Supervisor") rows=rows.filter(r=>r.role!=="Gerente" || r.user===currentUser.username);
  if(currentUser.role==="Cajero") rows=rows.filter(r=>r.user===currentUser.username);
  rows=filterByDateRange(rows,"auditDateFrom","auditDateTo");
  if(q){
    rows=rows.filter(r=>
      r.user.toLowerCase().includes(q) ||
      r.role.toLowerCase().includes(q) ||
      r.action.toLowerCase().includes(q) ||
      r.detail.toLowerCase().includes(q)
    );
  }
  $("auditTableWrap").innerHTML=`
    <table>
      <thead><tr><th>Fecha</th><th>Usuario</th><th>Rol</th><th>Acción</th><th>Detalle</th></tr></thead>
      <tbody>
        ${rows.length ? rows.map(r=>`
          <tr>
            <td>${new Date(r.date).toLocaleString("es-DO")}</td>
            <td>${r.user}</td>
            <td>${r.role}</td>
            <td>${r.action}</td>
            <td>${r.detail}</td>
          </tr>
        `).join("") : `<tr><td colspan="5">Sin resultados.</td></tr>`}
      </tbody>
    </table>
  `;
}

function renderDashboard(state,currentUser){
  let branches=[...state.branches], boxes=[...state.boxes];
  const movs=filterRowsByRole([...state.movements],state,currentUser);
  const treasury=filterRowsByRole([...state.treasury],state,currentUser);
  if(currentUser.role==="Supervisor"||currentUser.role==="Cajero"){
    branches=branches.filter(b=>b.id===currentUser.branchId);
    boxes=boxes.filter(b=>b.branchId===currentUser.branchId);
  }
  const cashTotal=branches.reduce((acc,b)=>acc+b.cash,0);
  const avgCash=boxes.length ? boxes.reduce((acc,b)=>acc+b.balance,0)/boxes.length : 0;
  const today=new Date().toDateString();
  const txToday=movs.filter(m=>new Date(m.date).toDateString()===today).length;
  const openBoxes=boxes.filter(b=>b.status==="Abierta").length;
  const alerts=computeAlerts(state,currentUser).length;
  const recentOps=Math.min(movs.length+treasury.length,10);
  const activeUsers=currentUser.role==="Gerente"
    ? state.users.filter(u=>u.active).length
    : state.users.filter(u=>u.active && u.branchId===currentUser.branchId).length;

  $("kpiCashTotal").textContent=formatMoney(cashTotal);
  $("kpiAvgCash").textContent=formatMoney(avgCash);
  $("kpiTxCount").textContent=String(txToday);
  $("kpiAlerts").textContent=String(alerts);
  $("kpiOpenBoxes").textContent=String(openBoxes);
  $("kpiUsers").textContent=String(activeUsers);
  $("kpiRecentOps").textContent=String(recentOps);

  renderBranchBars(state,currentUser);
  renderAlerts(state,currentUser);
  renderRecentOps(state,currentUser);
  renderCashTrends(state,currentUser);
}

function validateRoleLimit(user,amount,actionLabel){
  const max=user.limit || ROLE_LIMITS[user.role] || 0;
  if(amount>max){
    return `Límite excedido: ${user.role} solo puede aprobar hasta ${formatMoney(max)} y se intentó ${formatMoney(amount)} en ${actionLabel}.`;
  }
  return "";
}
function login(){
  hideMessages();
  const state=ensureState();
  const username=$("loginUser").value.trim();
  const password=$("loginPass").value.trim();
  const user=state.users.find(u=>u.username===username);
  if(!user) return showLoginMsg("Usuario no encontrado.");
  if(user.password!==password) return showLoginMsg("Contraseña incorrecta.");
  saveSession({username:user.username,role:user.role});
  if($("rememberUser").checked) setRememberedUser(username); else clearRememberedUser();
  addAudit(state,"Inicio de sesión",`Acceso al sistema con rol ${user.role}`);
  saveState(state);
  render();
}

function logout(){
  const state=ensureState();
  addAudit(state,"Cierre de sesión","Salida del sistema");
  saveState(state);
  clearSession();
  render();
}

function addBranch(){
  const state=ensureState(), currentUser=getCurrentUser(state);
  if(!currentUser || currentUser.role!=="Gerente") return;
  const name=$("branchName").value.trim();
  const zone=$("branchZone").value.trim();
  const cash=parseAmount($("branchCash").value);
  if(!name || !zone || !Number.isFinite(cash) || cash<0) return;
  state.branches.push({id:uid(),name,zone,cash});
  addAudit(state,"Registro de sucursal",`${name} (${zone}) con efectivo inicial ${formatMoney(cash)}`);
  saveState(state);
  $("branchName").value=""; $("branchZone").value=""; $("branchCash").value="";
  render();
}

function addBox(){
  const state=ensureState(), currentUser=getCurrentUser(state);
  if(!currentUser || (currentUser.role!=="Gerente" && currentUser.role!=="Supervisor")) return;
  const branchId=$("boxBranch").value, name=$("boxName").value.trim(), responsible=$("boxResponsible").value.trim(), balance=parseAmount($("boxCash").value);
  if(!branchId || !name || !responsible || !Number.isFinite(balance) || balance<0) return;
  if(currentUser.role==="Supervisor" && branchId!==currentUser.branchId) return;
  state.boxes.push({id:uid(),branchId,name,responsible,balance,status:"Cerrada"});
  addAudit(state,"Registro de caja",`${name} en ${getBranchName(state,branchId)} asignada a ${responsible}`);
  saveState(state);
  $("boxName").value=""; $("boxResponsible").value=""; $("boxCash").value="";
  render();
}

function addMovement(simulateAlert=false){
  hideMessages();
  const state=ensureState(), currentUser=getCurrentUser(state);
  if(!currentUser || currentUser.role==="Auditor") return showMovementMsg("No tienes permisos para registrar movimientos.","err");
  const type=$("mvType").value, branchId=$("mvBranch").value, boxId=$("mvBox").value, channel=$("mvChannel").value;
  const amount=parseAmount($("mvAmount").value), responsible=$("mvResponsible").value.trim(), detail=$("mvDetail").value.trim();
  if(!branchId || !boxId || !Number.isFinite(amount) || amount<0 || !responsible || !detail) return showMovementMsg("Completa todos los campos correctamente.","err");
  if((currentUser.role==="Supervisor"||currentUser.role==="Cajero") && branchId!==currentUser.branchId) return showMovementMsg("No puedes operar fuera de tu sucursal asignada.","err");
  const branch=state.branches.find(b=>b.id===branchId), box=state.boxes.find(b=>b.id===boxId);
  if(!branch || !box) return showMovementMsg("Sucursal o caja inválida.","err");
  const needsStrict=["Retiro","Transferencia Interna","Reabastecimiento","Depósito"].includes(type);
  const limitError=needsStrict ? validateRoleLimit(currentUser,amount,type) : "";
  if(limitError){ addAudit(state,"Intento bloqueado por límite",limitError); saveState(state); return showMovementMsg(limitError,"err"); }

  let alert="";
  if(simulateAlert || amount>100000) alert=`Límite excedido en ${box.name} por operación de ${formatMoney(amount)}.`;

  if(type==="Depósito" || type==="Reabastecimiento"){ branch.cash+=amount; box.balance+=amount; }
  else if(type==="Retiro"){ branch.cash-=amount; box.balance-=amount; }
  else if(type==="Transferencia Interna"){ branch.cash+=amount; }

  state.movements.unshift({id:uid(),date:nowISO(),type,branchId,boxId,channel,amount,responsible,detail,alert});
  addAudit(state,"Registro de movimiento",`${type} por ${formatMoney(amount)} en ${box.name} - ${branch.name}`);
  saveState(state);
  $("mvAmount").value=""; $("mvResponsible").value=""; $("mvDetail").value="";
  showMovementMsg("Movimiento registrado correctamente.","ok");
  render();
}

function requestFunds(){
  const state=ensureState(), currentUser=getCurrentUser(state);
  if(!currentUser || currentUser.role==="Auditor") return;
  const branchId=$("fundBranch").value, amount=parseAmount($("fundAmount").value), reason=$("fundReason").value.trim();
  if(!branchId || !Number.isFinite(amount) || amount<=0 || !reason) return;
  if((currentUser.role==="Supervisor"||currentUser.role==="Cajero") && branchId!==currentUser.branchId) return;
  state.treasury.unshift({id:uid(),date:nowISO(),kind:"Solicitud de fondos",branchId,amount,detail:reason,status:"Pendiente",approvedBy:null});
  addAudit(state,"Solicitud de fondos",`${getBranchName(state,branchId)} solicita ${formatMoney(amount)} por ${reason}`);
  saveState(state);
  $("fundAmount").value=""; $("fundReason").value="";
  render();
}

function approveFund(id,approved){
  const state=ensureState(), currentUser=getCurrentUser(state), item=state.treasury.find(t=>t.id===id);
  if(!item || !currentUser) return;
  if(currentUser.role!=="Gerente" && currentUser.role!=="Supervisor") return;
  if(currentUser.role==="Supervisor" && item.branchId!==currentUser.branchId) return;
  const limitError=validateRoleLimit(currentUser,item.amount,approved?"Aprobación de fondos":"Rechazo de fondos");
  if(approved && limitError && currentUser.role!=="Gerente"){ addAudit(state,"Intento bloqueado por límite",limitError); saveState(state); return; }
  item.status=approved?"Aprobada":"Rechazada";
  item.approvedBy=currentUser.username;
  if(approved){ const branch=state.branches.find(b=>b.id===item.branchId); if(branch) branch.cash+=item.amount; }
  addAudit(state,approved?"Aprobación de fondos":"Rechazo de fondos",`${currentUser.username} ${approved?"aprobó":"rechazó"} solicitud de ${formatMoney(item.amount)} para ${getBranchName(state,item.branchId)}`);
  saveState(state);
  render();
}

function createRemittance(){
  const state=ensureState(), currentUser=getCurrentUser(state);
  if(!currentUser || (currentUser.role!=="Gerente" && currentUser.role!=="Supervisor")) return showMovementMsg("No tienes permisos para programar remesas.","err");
  const branchId=$("remBranch").value, amount=parseAmount($("remAmount").value), destination=$("remDestination").value, carrier=$("remCarrier").value;
  if(!branchId || !Number.isFinite(amount) || amount<=0 || !destination) return;
  if(currentUser.role==="Supervisor" && branchId!==currentUser.branchId) return showMovementMsg("No puedes programar remesas fuera de tu sucursal.","err");
  const limitError=validateRoleLimit(currentUser,amount,"Remesa");
  if(limitError && currentUser.role!=="Gerente"){ addAudit(state,"Intento bloqueado por límite",limitError); saveState(state); return showMovementMsg(limitError,"err"); }
  const branch=state.branches.find(b=>b.id===branchId); if(!branch) return;
  branch.cash-=amount;
  state.treasury.unshift({id:uid(),date:nowISO(),kind:"Remesa",branchId,amount,detail:`Destino: ${destination} · Transporte: ${carrier}`,status:"Programada"});
  addAudit(state,"Programación de remesa",`${getBranchName(state,branchId)} programa remesa de ${formatMoney(amount)} hacia ${destination} con ${carrier}`);
  saveState(state);
  $("remAmount").value="";
  render();
}

function addUser(){
  const state=ensureState(), currentUser=getCurrentUser(state);
  if(!currentUser || currentUser.role!=="Gerente") return;
  const name=$("newUserName").value.trim(), username=$("newUsername").value.trim(), role=$("newUserRole").value, branchId=$("newUserBranch").value;
  if(!name || !username || !branchId) return;
  if(state.users.some(u=>u.username===username)) return;
  state.users.push({id:uid(),name,username,password:"123",role,branchId,active:true,limit:ROLE_LIMITS[role]||0});
  addAudit(state,"Registro de usuario",`${name} (${username}) con rol ${role}`);
  saveState(state);
  $("newUserName").value=""; $("newUsername").value="";
  render();
}

function openModal(mode){ modalMode=mode; $("modal").classList.remove("hidden"); $("modalTitle").textContent=mode==="open"?"Apertura de caja":"Cierre de caja"; $("modalHint").textContent=mode==="open"?"Registra el efectivo inicial de apertura.":"Registra el valor final para cierre o arqueo."; $("modalAmount").value=""; $("modalDetail").value="" }
function closeModal(){ $("modal").classList.add("hidden"); modalMode=null }

function confirmModalAction(){
  const state=ensureState(), currentUser=getCurrentUser(state);
  if(!currentUser || currentUser.role==="Auditor") return;
  const branchId=$("modalBranch").value, boxId=$("modalBox").value, amount=parseAmount($("modalAmount").value);
  const detail=$("modalDetail").value.trim() || (modalMode==="open"?"Apertura operativa":"Cierre operativo");
  if(!branchId || !boxId || !Number.isFinite(amount) || amount<0) return;
  if((currentUser.role==="Supervisor"||currentUser.role==="Cajero") && branchId!==currentUser.branchId) return;
  const limitError=validateRoleLimit(currentUser,amount,modalMode==="open"?"Apertura":"Cierre");
  if(limitError && amount>0){ addAudit(state,"Intento bloqueado por límite",limitError); saveState(state); return; }
  const box=state.boxes.find(b=>b.id===boxId), branch=state.branches.find(b=>b.id===branchId);
  if(!box || !branch) return;
  if(modalMode==="open"){ box.status="Abierta"; box.balance=amount; addAudit(state,"Apertura de caja",`${box.name} abierta con ${formatMoney(amount)} en ${branch.name}`); }
  else { box.status="Cerrada"; box.balance=amount; addAudit(state,"Cierre de caja",`${box.name} cerrada con ${formatMoney(amount)} en ${branch.name}`); }
  state.movements.unshift({id:uid(),date:nowISO(),type:modalMode==="open"?"Apertura":"Cierre",branchId,boxId,channel:"Efectivo",amount,responsible:loadSession()?.username||"Sistema",detail});
  saveState(state); closeModal(); render();
}

function exportAudit(){
  const state=ensureState(), currentUser=getCurrentUser(state);
  if(!currentUser || !["Gerente","Supervisor","Auditor"].includes(currentUser.role)) return;
  let rowsData=[...state.audit];
  if(currentUser.role==="Supervisor") rowsData=rowsData.filter(r=>r.role!=="Gerente" || r.user===currentUser.username);
  const rows=[["Fecha","Usuario","Rol","Accion","Detalle"]];
  rowsData.forEach(a=>rows.push([new Date(a.date).toLocaleString("es-DO"),a.user,a.role,a.action,a.detail]));
  const csv=rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\n");
  const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"});
  const url=URL.createObjectURL(blob); const link=document.createElement("a");
  link.href=url; link.download="auditoria_banco_la_tendencia.csv"; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
}

function seedDemoData(){
  const state=ensureState();
  [
    { type:"Depósito", branchId:"b1", boxId:"x1", channel:"Efectivo", amount:18000, responsible:"Laura Pérez", detail:"Ingreso de efectivo por ventanilla" },
    { type:"Retiro", branchId:"b2", boxId:"x3", channel:"Efectivo", amount:12000, responsible:"Carlos Núñez", detail:"Retiro autorizado" },
    { type:"Reabastecimiento", branchId:"b3", boxId:"x6", channel:"Efectivo", amount:25000, responsible:"Pedro Lara", detail:"Reabastecimiento de caja" },
    { type:"Arqueo", branchId:"b1", boxId:"x2", channel:"Efectivo", amount:0, responsible:"Julio Martínez", detail:"Arqueo sin diferencias" }
  ].forEach((m,i)=>state.movements.unshift({id:uid(),date:new Date(Date.now()-i*86400000).toISOString(),...m}));

  state.treasury.unshift({id:uid(),date:nowISO(),kind:"Solicitud de fondos",branchId:"b2",amount:90000,detail:"Incremento de demanda operativa",status:"Pendiente"});
  state.treasury.unshift({id:uid(),date:nowISO(),kind:"Remesa",branchId:"b1",amount:60000,detail:"Destino: Tesorería Central · Transporte: Prosegur",status:"Programada"});
  addAudit(state,"Carga demo","Se agregaron movimientos y tesorería de ejemplo");
  saveState(state); render();
}

function resetSystem(){ localStorage.removeItem(LS.state); localStorage.removeItem(LS.session); localStorage.removeItem(LS.remembered); hideMessages(); render(); }

function render(){
  const state=ensureState(), currentUser=getCurrentUser(state), session=loadSession();
  $("viewLogin").classList.toggle("hidden",!!session && !!currentUser);
  $("viewApp").classList.toggle("hidden",!(!!session && !!currentUser));
  $("btnLogout").classList.toggle("hidden",!(!!session && !!currentUser));
  $("sessionBadge").classList.toggle("hidden",!(!!session && !!currentUser));
  if(!session || !currentUser){
    const remembered=getRememberedUser();
    if(remembered){ $("loginUser").value=remembered; $("rememberUser").checked=true; }
    return;
  }
  $("sessionBadge").textContent=`${session.username} · ${session.role}`;
  $("userDisplay").textContent=`${currentUser.name} · ${currentUser.role}`;
  enforceTabAccess(state,currentUser);
  enforceSectionVisibility(currentUser);
  updateBranchSelects(state,currentUser);
  document.querySelectorAll(".nav-btn").forEach(btn=>btn.classList.toggle("active",btn.dataset.tab===state.settings.currentTab));
  document.querySelectorAll(".tab-panel").forEach(panel=>panel.classList.toggle("hidden",panel.dataset.panel!==state.settings.currentTab));
  renderDashboard(state,currentUser);
  renderBranchesTable(state,currentUser);
  renderBoxesTable(state,currentUser);
  renderMovementsTable(state,currentUser);
  renderTreasuryTable(state,currentUser);
  renderUsersTable(state,currentUser);
  renderAuditTable(state,currentUser);
}

document.addEventListener("click",(e)=>{
  const nav=e.target.closest(".nav-btn"); if(nav) setTab(nav.dataset.tab);
  const approve=e.target.closest(".approve-fund"); if(approve) approveFund(approve.dataset.id,true);
  const reject=e.target.closest(".reject-fund"); if(reject) approveFund(reject.dataset.id,false);
});

$("btnLogin").addEventListener("click",login);
$("loginPass").addEventListener("keydown",(e)=>{ if(e.key==="Enter") login() });
$("btnTogglePass").addEventListener("click",()=>{ const input=$("loginPass"); input.type=input.type==="password"?"text":"password" });
$("btnForgot").addEventListener("click",()=>showLoginMsg("Credenciales demo: Julio / 123","ok"));
$("btnLogout").addEventListener("click",logout);
$("btnAddBranch").addEventListener("click",addBranch);
$("btnAddBox").addEventListener("click",addBox);
$("btnAddMovement").addEventListener("click",()=>addMovement(false));
$("btnSimulateLimit").addEventListener("click",()=>addMovement(true));
$("btnRequestFunds").addEventListener("click",requestFunds);
$("btnCreateRemittance").addEventListener("click",createRemittance);
$("btnAddUser").addEventListener("click",addUser);
$("btnOpenCash").addEventListener("click",()=>openModal("open"));
$("btnCloseCash").addEventListener("click",()=>openModal("close"));
$("btnCancelModal").addEventListener("click",closeModal);
$("btnConfirmModal").addEventListener("click",confirmModalAction);
$("btnExportAudit").addEventListener("click",exportAudit);
$("btnSeedDemo").addEventListener("click",seedDemoData);
$("btnResetSystem").addEventListener("click",resetSystem);
$("mvSearch").addEventListener("input",render);
$("mvFilterType").addEventListener("change",render);
$("mvDateFrom").addEventListener("change",render);
$("mvDateTo").addEventListener("change",render);
$("auditSearch").addEventListener("input",render);
$("auditDateFrom").addEventListener("change",render);
$("auditDateTo").addEventListener("change",render);
$("branchZoneFilter").addEventListener("change",render);
$("boxResponsibleFilter").addEventListener("input",render);
$("mvBranch").addEventListener("change",()=>{ const s=ensureState(),u=getCurrentUser(s); updateBoxSelects(s,u) });
$("modalBranch").addEventListener("change",()=>{ const s=ensureState(),u=getCurrentUser(s); updateBoxSelects(s,u) });

(function init(){
  ensureState();
  const remembered=getRememberedUser();
  if(remembered){ $("loginUser").value=remembered; $("rememberUser").checked=true; }
  render();
})();
